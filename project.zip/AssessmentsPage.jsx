// src/pages/AssessmentsPage.jsx
import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import AssessmentCard from "../components/AssessmentCard";
import StartAssessmentModal from "../components/StartAssessmentModal";
import { assessments as api } from "../api/api";

function EmptyState() {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "60px 0", gap: 14 }}>
      <svg width="90" height="90" viewBox="0 0 80 80" fill="none" style={{ opacity: 0.35 }}>
        <circle cx="52" cy="10" r="10" fill="#b0b8cc"/>
        <rect x="10" y="30" width="60" height="38" rx="4" fill="#c8cfe0"/>
        <rect x="18" y="22" width="44" height="28" rx="3" fill="#dce2f0"/>
        <rect x="24" y="30" width="32" height="3" rx="1.5" fill="#b0b8cc"/>
        <rect x="24" y="36" width="22" height="3" rx="1.5" fill="#b0b8cc"/>
      </svg>
      <span style={{ fontSize: 13, color: "#aaa", fontStyle: "italic", fontFamily: "'Space Grotesk', sans-serif" }}>No Assessments Found.</span>
    </div>
  );
}

export default function AssessmentsPage({ onNavigate, onStartTest, username, onLogout }) {
  const [activeTab,          setActiveTab]          = useState("active");
  const [activeList,         setActiveList]         = useState([]);
  const [completedList,      setCompletedList]      = useState([]);
  const [loading,            setLoading]            = useState(true);
  const [showStartModal,     setShowStartModal]     = useState(false);
  const [selectedAssessment, setSelectedAssessment] = useState(null);

  useEffect(() => {
    api.list()
      .then(({ active, completed }) => {
        setActiveList(active || []);
        setCompletedList(completed || []);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  function handleStartTest(assessment) {
    setSelectedAssessment(assessment);
    setShowStartModal(true);
  }

  function handleConfirmStart() {
    setShowStartModal(false);
    onStartTest(selectedAssessment);
  }

  const tabStyle = (tab) => ({
    padding: "10px 20px 12px", fontSize: 14, fontWeight: 600,
    fontFamily: "'Space Grotesk', sans-serif",
    color: activeTab === tab ? "#1a5cff" : "#888",
    cursor: "pointer", border: "none", background: "none",
    borderBottom: activeTab === tab ? "3px solid #1a5cff" : "3px solid transparent",
  });

  const badgeStyle = { background: "#f5c518", color: "#111", fontWeight: 700, fontSize: 12, fontFamily: "'Space Grotesk', sans-serif", padding: "2px 8px", borderRadius: 10, minWidth: 28, textAlign: "center" };
  const gridStyle  = { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20 };

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh", background: "#e8eaed", fontFamily: "'Space Grotesk', sans-serif" }}>
      <Navbar activePage="assessments" onNavigate={onNavigate} username={username} onLogout={onLogout} />

      <div style={{ background: "#fffbe6", borderBottom: "1px solid #e0ddd0", padding: "22px 48px 0" }}>
        <h2 style={{ fontSize: 32, fontWeight: 400, color: "#191919", marginBottom: 16, fontFamily: "'Space Grotesk', sans-serif" }}>Assessments</h2>
        <div style={{ display: "flex", gap: 0 }}>
          <button style={tabStyle("active")}    onClick={() => setActiveTab("active")}>Active</button>
          <button style={tabStyle("completed")} onClick={() => setActiveTab("completed")}>Completed</button>
        </div>
      </div>

      <div style={{ padding: "28px 48px" }}>
        {loading ? (
          <div style={{ color: "#aaa", fontFamily: "'Space Grotesk', sans-serif", fontSize: 14 }}>Loading assessments…</div>
        ) : activeTab === "active" ? (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 24, fontWeight: 400, color: "#1a5cff", marginBottom: 24, fontFamily: "'Space Grotesk', sans-serif" }}>
              Active Assessments <span style={badgeStyle}>{activeList.length}</span>
            </div>
            {activeList.length === 0 ? <EmptyState /> : (
              <div style={gridStyle}>
                {activeList.map(a => (
                  <AssessmentCard key={a.id} assessment={{ ...a, totalSections: a.total_sections, totalQuestions: a.total_questions, duration: `${a.duration_mins}m`, startDate: a.start_date }} onStartTest={() => handleStartTest(a)} />
                ))}
              </div>
            )}
          </div>
        ) : (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 24, fontWeight: 400, color: "#1a5cff", marginBottom: 24, fontFamily: "'Space Grotesk', sans-serif" }}>
              Completed Assessments <span style={badgeStyle}>{completedList.length}</span>
            </div>
            {completedList.length === 0 ? <EmptyState /> : (
              <div style={gridStyle}>
                {completedList.map(a => (
                  <AssessmentCard key={a.id} assessment={{ ...a, totalSections: a.total_sections, totalQuestions: a.total_questions, duration: `${a.duration_mins}m` }} />
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <StartAssessmentModal open={showStartModal} onConfirm={handleConfirmStart} onCancel={() => setShowStartModal(false)} />
    </div>
  );
}