// src/App.jsx
import React, { useState, useEffect } from "react";
import "./styles/global.css";
import { auth } from "./api/api";

import LoginPage                  from "./pages/LoginPage";
import DashboardPage              from "./pages/DashboardPage";
import AssessmentsPage            from "./pages/AssessmentsPage";
import TestSectionsPage           from "./pages/TestSectionsPage";
import ProctorVerifyPage          from "./pages/ProctorVerifyPage";
import TestInstructionsPage       from "./pages/TestInstructionsPage";
import NavigationInstructionsPage from "./pages/NavigationInstructionsPage";
import SettleInPage               from "./pages/SettleInPage";
import QuestionListPage           from "./pages/QuestionListPage";
import MCQPage                    from "./pages/MCQPage";
import CodingPage                 from "./pages/CodingPage";

export default function App() {
  const [page,               setPage]               = useState("loading");
  const [user,               setUser]               = useState(null);
  const [selectedAssessment, setSelectedAssessment]  = useState(null);
  const [selectedSection,    setSelectedSection]     = useState(null);
  const [startQuestionIdx,   setStartQuestionIdx]    = useState(0);
  const [loadError,          setLoadError]           = useState(null);

  // ── Restore session on mount ──────────────────────────────────────────────
  useEffect(() => {
    auth.me()
      .then(result => {
        if (result?.user) {
          setUser(result.user);
          setPage("dashboard");
        } else {
          setPage("login");
        }
      })
      .catch(() => setPage("login"));
  }, []);

  function handleLogin(userData) {
    setUser(userData);
    setPage("dashboard");
  }

  function handleLogout() {
    auth.logout().finally(() => {
      setUser(null);
      setPage("login");
    });
  }

  function navigate(target) { setPage(target); }

  function handleStartTest(assessment) {
    setSelectedAssessment(assessment);
    setPage("proctor-verify");
  }

  function handleStartSection(section) {
    // Attach assessment_id so CodingPage / MCQPage can call the questions API.
    // TestSectionsPage receives the full assessment object, so we pull the id from there.
    const enrichedSection = { ...section, assessment_id: selectedAssessment?.id };
    setSelectedSection(enrichedSection);
    // Route Coding sections to CodingPage, everything else to QuestionListPage
    if (section.type === "Coding" || section.type === "CODE") {
      setPage("coding");
    } else {
      setPage("question-list");
    }
  }

  function handleOpenQuestion(section, questionIdx) {
    setSelectedSection(section);
    setStartQuestionIdx(questionIdx);
    // Route by section type
    if (section.type === "Coding" || section.type === "CODE") {
      setPage("coding");
    } else {
      setPage("mcq");
    }
  }

  // ── Loading spinner ───────────────────────────────────────────────────────
  if (page === "loading") {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", fontFamily: "'Space Grotesk', sans-serif", color: "#888" }}>
        Loading…
      </div>
    );
  }

  if (page === "login")
    return <LoginPage onLogin={handleLogin} />;

  if (page === "dashboard")
    return <DashboardPage username={user?.name || "User"} onNavigate={navigate} onLogout={handleLogout} />;

  if (page === "assessments")
    return (
      <AssessmentsPage
        onNavigate={navigate}
        username={user?.name || "User"}
        onLogout={handleLogout}
        onStartTest={handleStartTest}
      />
    );

  if (page === "proctor-verify")
    return (
      <ProctorVerifyPage
        assessment={selectedAssessment}
        onSuccess={() => navigate("instructions")}
        onCancel={() => navigate("assessments")}
      />
    );

  if (page === "instructions")
    return (
      <TestInstructionsPage
        assessment={selectedAssessment}
        onStart={() => navigate("nav-instructions")}
      />
    );

  if (page === "nav-instructions")
    return (
      <NavigationInstructionsPage
        duration={selectedAssessment?.duration || "30 minutes"}
        onContinue={() => navigate("settle-in")}
      />
    );

  if (page === "settle-in")
    return <SettleInPage seconds={10} onComplete={() => navigate("test-sections")} />;

  if (page === "test-sections")
    return (
      <TestSectionsPage
        assessment={selectedAssessment}
        onNavigate={navigate}
        username={user?.name || "User"}
        onLogout={handleLogout}
        onEndTest={() => navigate("assessments")}
        onStartSection={handleStartSection}
      />
    );

  if (page === "question-list")
    return (
      <QuestionListPage
        section={selectedSection}
        userId={user?.id}
        onOpenQuestion={(idx) => handleOpenQuestion(selectedSection, idx)}
        onSubmitSection={() => navigate("test-sections")}
        onEndTest={() => navigate("assessments")}
      />
    );

  if (page === "mcq")
    return (
      <MCQPage
        section={selectedSection}
        startIndex={startQuestionIdx}
        userId={user?.id}
        onBackToList={() => navigate("question-list")}
        onSubmitSection={() => navigate("test-sections")}
      />
    );

  if (page === "coding")
    return (
      <CodingPage
        section={selectedSection}
        startIndex={startQuestionIdx}
        userId={user?.id}
        onBackToList={() => navigate("question-list")}
        onSubmitSection={() => navigate("test-sections")}
      />
    );

  return null;
}