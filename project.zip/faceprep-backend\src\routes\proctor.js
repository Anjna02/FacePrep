// src/routes/proctor.js
const express = require("express");
const db      = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// ── POST /api/proctor/verify ─────────────────────────────────────────────────
// Body: { code, assessmentId }
router.post("/verify", requireAuth, (req, res) => {
  const { code, assessmentId } = req.body;

  if (!code) {
    return res.status(400).json({ error: "Proctor code is required" });
  }

  const row = db.prepare(
    "SELECT * FROM proctor_codes WHERE code = ?"
  ).get(String(code).trim());

  if (!row) {
    return res.status(401).json({ error: "Invalid proctor code" });
  }

  // Check expiry
  if (row.expires_at && row.expires_at < Math.floor(Date.now() / 1000)) {
    return res.status(401).json({ error: "Proctor code has expired" });
  }

  // If assessmentId is provided, check the code belongs to that assessment (or is universal)
  if (assessmentId && row.assessment_id && row.assessment_id !== Number(assessmentId)) {
    return res.status(401).json({ error: "Proctor code is not valid for this assessment" });
  }

  res.json({ ok: true, assessmentId: row.assessment_id });
});

module.exports = router;